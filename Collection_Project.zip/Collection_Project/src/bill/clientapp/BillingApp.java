package bill.clientapp;

import java.util.List;
import java.util.Scanner;

import bill.model.AdminLogin;
import bill.model.CustomerLogin;
import bill.model.Product;
import bill.model.User;
import bill.service.*;

public class BillingApp {
	static Scanner s = new Scanner(System.in);
	static UserResisterService userRegService = new UserResisterServiceImpl();
	static ValidateUserService validateUser = new ValidateUserServiceImpl();
	static ProductService prodService=new ProductServiceImpl();
	static User user = null;
	static String x[];
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		do {
			x=args;
			System.out.println("1. Customer Master");
			System.out.println("2. Admin Master");
			// System.out.println("3.");
			System.out.println("Enter your choice");
			int choice = s.nextInt();
			switch (choice) {
			case 1:
				customerMenu();
				break;
			case 2:
				adminMenu();
				break;
			case 3:
				break;
			default:
				System.out.println("Wrong choice");
			}
		} while (true);
	}

	public static void customerMenu() {
		do {
			System.out.println("1. Resister");
			System.out.println("2. Login");
			System.out.println("Enter Your Choice");
			int choice = s.nextInt();
			s.nextLine();
			switch (choice) {
			case 1:

				System.out.println("Engter Name,Email,Contact,UserName and password as well as address of customer");
				String name = s.nextLine();
				String email = s.nextLine();
				String contact = s.nextLine();
				String username = s.nextLine();
				String password = s.nextLine();
				String address = s.nextLine();
				CustomerLogin custLogin = new CustomerLogin(name, email, contact, username, password, address);
				boolean b = userRegService.registerUser(custLogin);
				if (b) {
					System.out.println("Registration Success.....................");
				} else {
					System.out.println("Registration Faild.....................");
				}
				break;
			case 2:
				user = new CustomerLogin();
				System.out.println("Enter Username");
				username = s.nextLine();
				System.out.println("Enter passwoard");
				password = s.nextLine();
				user.setUsername(username);
				user.setPassword(password);
				user = validateUser.validateUser(user);
				if (user != null) {
					System.out.println("Login Success..............");
					customerMaster();
				} else {
					System.out.println("Login  Failed..............");
				}
				break;
			case 3:
				break;
			default:
				System.out.println("Wrong choice");
			}
		} while (true);
	}

	public static void adminMenu() {
		do {
			System.out.println("1.Login");
			System.out.println("2.Add New Product");
			System.out.println("Enter your choice");
			int choice = s.nextInt();
			switch (choice) {
			case 1:
				user = new AdminLogin();
				user.setUsername("admin");
				user.setPassword("admin");
				user = validateUser.validateUser(user);
				if (user != null) {
					System.out.println("Admin Login Successfully...................");
					adminMaster();
				} else {
					System.out.println("Admin Login Faild............................");
				}
				break;
			case 2:
				break;
			default:
				System.out.println("Wrong choice");
			}
		} while (true);
	}

	private static void adminMaster() {
		do {
			System.out.println("1.Add New product");
			System.out.println("2.Viwe All product");
			System.out.println("3.Main Menu");
			System.out.println("Enter Your Choice");
			int choice=s.nextInt();
			switch(choice) {
			case 1:
				s.nextLine();
				System.out.println("Enter Product id,name,price,company and stock value");
				int prodid=s.nextInt();
				s.nextLine();
				String prodName = s.nextLine();
				int price=s.nextInt();
				s.nextLine();
				String comp=s.nextLine();
				int stockVal=s.nextInt();
				Product p=new Product(prodid,prodName,price,comp,stockVal);
				boolean b=prodService.isAddNewProduct(p);
				if(b) {
					System.out.println("Product Added Successfully");
				}
				else {
					System.out.println("Some problem is there");
				}
			break;
			case 2:
				List prodList=prodService.getAllProducts();
				for(Object obj:prodList) {
					p=(Product)obj;
					System.out.println(p.getId()+"\t"+p.getName()+"\t"+p.getPrice()+"\t"+p.getCompName()+"\t"+p.getStockValue());
				}
				break;
			case 3:
				main(x);
				break;
			default:
				System.out.println("Invalide Choice");
			}
		}while(true);
		
	}
	public static void customerMaster() {
		do {
			System.out.println("Welcome User In Application");
			System.out.println("1.Place Order");
			System.out.println("Enter your choice");
			int choice = s.nextInt();
			switch(choice) {
			case 1:
				List prodList=prodService.getAllProducts();
				System.out.println("Product List");
				System.out.println("Enter Product Id for Place order");
				for(Object obj:prodList) {
					Product p=(Product)obj;
					System.out.println(p.getId()+"\t"+p.getName()+"\t"+p.getPrice()+"\t"+p.getCompName()+"\t"+p.getStockValue());
				}
				break;
			case 2:
				
				break;
			default:
				System.out.println("Wrong choice");
			}
			
		}while(true);
	}
}
