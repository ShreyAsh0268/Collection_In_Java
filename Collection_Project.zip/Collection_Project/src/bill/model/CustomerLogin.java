package bill.model;

import java.util.List;

public class CustomerLogin extends User {

	private String address;
	private final String role = "customer";
	public List listOrder;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List getListOrder() {
		return listOrder;
	}

	public void setListOrder(List listOrder) {
		this.listOrder = listOrder;
	}

	public CustomerLogin() {

	}

	public CustomerLogin(List order) {
		this.listOrder = order;
	}

	public CustomerLogin(String name, String email, String contact, String username, String password, String address) {
		super(name, email, contact, username, password);
		this.address = address;
		// TODO Auto-generated constructor stub
	}

	public String getRole() {
		return role;
	}
}
