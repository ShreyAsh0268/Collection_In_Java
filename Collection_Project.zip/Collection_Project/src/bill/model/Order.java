package bill.model;

import java.util.Date;
import java.util.List;

public class Order {

	private int oid;
	private Date odate;
	private List orderProdList;

	public int getOid() {
		return oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}

	public Date getOdate() {
		return odate;
	}

	public void setOdate(Date odate) {
		this.odate = odate;
	}

	public List getOrderProdList() {
		return orderProdList;
	}

	public void setOrderProdList(List orderProdList) {
		this.orderProdList = orderProdList;
	}

}
