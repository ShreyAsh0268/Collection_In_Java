package bill.model;

public class AdminLogin extends User {

	public AdminLogin() {
		
	}

	public AdminLogin(String name, String email, String contact, String username, String password) {
		super(name, email, contact, username, password);
		// TODO Auto-generated constructor stub
	}
	
}
