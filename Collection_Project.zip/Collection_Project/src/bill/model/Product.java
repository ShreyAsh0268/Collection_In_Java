package bill.model;

public class Product {
	public Product() {
		
	}
	
	public Product(int id, String name, int price, String compName, int stockValue) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.compName = compName;
		this.stockValue = stockValue;
	}
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public int getStockValue() {
		return stockValue;
	}
	public void setStockValue(int stockValue) {
		this.stockValue = stockValue;
	}
	private String name;
	private int price;
	private String compName;
	private int stockValue;
}
