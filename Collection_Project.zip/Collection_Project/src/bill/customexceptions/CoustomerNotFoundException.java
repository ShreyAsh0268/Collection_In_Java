package bill.customexceptions;

import bill.model.User;

public class CoustomerNotFoundException extends RuntimeException{
	
	User user;
	public CoustomerNotFoundException(User user) {
		this.user=user;
	}
	public String getUserException(User user) {
		return "user not found credential"+user.getUsername()+","+user.getPassword();
		
	}

}
 