package bill.repository;

import java.util.List;

import bill.model.Product;

public interface ProductRepossitory {
	public boolean isAddNewProduct(Product model);
	//public List getAllProducts();
	public List getAllProducts(); 
}
