package bill.repository;

import java.util.List;
import bill.customexceptions.*;
import bill.model.CustomerLogin;
import bill.model.User;

public class ValidateUserRepositoryImpl implements ValidateUserRepository {

	UserResisterRepository userRegData = new UserResisterRepositoryImpl();

	@Override
	public User validateUser(User user) {
		// TODO Auto-generated method stub
		try {
			if (user.getUsername().equals("admin") && user.getPassword().equals("admin")) {
				return user;
			} else {
				List userList = userRegData.getAllCustomer();
				boolean flag = false;
				for (Object obj : userList) {
					CustomerLogin clogin = (CustomerLogin) obj;
					if (clogin.getUsername().equals(user.getUsername())
							&& clogin.getPassword().equals(user.getPassword()) && clogin.getRole().equals("customer")) {
						flag = true;

						break;
					}
				}
				if (!flag) {
					throw new CoustomerNotFoundException(user);
				}
			}
		} catch (CoustomerNotFoundException ex) {
			System.out.println(ex.getUserException(user));
			return null;
		}
		return user;
	}

}
