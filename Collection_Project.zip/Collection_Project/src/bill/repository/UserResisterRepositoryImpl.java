package bill.repository;

import bill.model.AdminLogin;
import bill.model.CustomerLogin;
import java.util.*;
public class UserResisterRepositoryImpl implements UserResisterRepository {

	static List regCustList = new Vector();
	@Override
	public boolean registerUser(CustomerLogin login) {
		boolean b= regCustList.add(login);
		show();
		return b;
	}
	public void show() {
		for(Object obj:regCustList) {
			CustomerLogin c=(CustomerLogin)obj;
		}
	}
	@Override
	public boolean registerUser(AdminLogin login) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public List getAllCustomer() {
		// TODO Auto-generated method stub
		return this.regCustList.size()>0?regCustList:null;
	}
	
	

}
