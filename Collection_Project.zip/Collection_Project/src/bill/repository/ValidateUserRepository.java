package bill.repository;

import bill.model.User;

public interface ValidateUserRepository {

	public User validateUser(User user);
}
