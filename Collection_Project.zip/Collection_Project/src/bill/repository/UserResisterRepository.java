package bill.repository;

import java.util.List;

import bill.model.AdminLogin;
import bill.model.CustomerLogin;

public interface UserResisterRepository {

	boolean registerUser(CustomerLogin login);
	boolean registerUser(AdminLogin login);
	public List getAllCustomer();
}
