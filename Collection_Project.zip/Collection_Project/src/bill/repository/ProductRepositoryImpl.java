package bill.repository;

import java.util.List;
import java.util.Vector;

import bill.model.Product;

public class ProductRepositoryImpl implements ProductRepossitory{

	private List prodList=new Vector();
	@Override
	public boolean isAddNewProduct(Product model) {
		return prodList.add(model);
	}
	public List getAllProducts() {
		return prodList;
	}

}
