package bill.repository;

public interface CustomerOrderRepository {

}
