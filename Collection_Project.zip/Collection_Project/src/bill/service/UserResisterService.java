package bill.service;

import bill.model.AdminLogin;
import bill.model.CustomerLogin;

public interface UserResisterService {
	public boolean registerUser(CustomerLogin login);
	public boolean registerUser(AdminLogin login);
}
