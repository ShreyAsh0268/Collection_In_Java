package bill.service;

import bill.model.AdminLogin;
import bill.model.CustomerLogin;
import bill.repository.UserResisterRepository;
import bill.repository.UserResisterRepositoryImpl;

public class UserResisterServiceImpl implements UserResisterService {

	UserResisterRepository regRepo = new UserResisterRepositoryImpl();
	@Override
	public boolean registerUser(CustomerLogin login) {
		// TODO Auto-generated method stub
		return regRepo.registerUser(login);
	}

	@Override
	public boolean registerUser(AdminLogin login) {
		// TODO Auto-generated method stub 
		return false;
	}

}
 