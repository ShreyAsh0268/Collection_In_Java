package bill.service;

import bill.model.User;

import bill.repository.*;
public class ValidateUserServiceImpl implements ValidateUserService{

	ValidateUserRepository validateRepo = new ValidateUserRepositoryImpl();
	@Override
	public User validateUser(User user) {
		// TODO Auto-generated method stub
		return validateRepo.validateUser(user);
	}

}
