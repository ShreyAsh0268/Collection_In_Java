package bill.service;

import bill.model.User;

public interface ValidateUserService {
	public User validateUser(User user); 
	
}
