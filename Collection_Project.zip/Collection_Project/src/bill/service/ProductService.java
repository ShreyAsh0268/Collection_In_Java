package bill.service;

import java.util.List;

import bill.model.Product;

public interface ProductService {
	public boolean isAddNewProduct(Product model); 
	public List getAllProducts();
	//public List getAllProducts();
}
