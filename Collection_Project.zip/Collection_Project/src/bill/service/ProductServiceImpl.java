package bill.service;

import java.util.List;

import bill.model.Product;
import bill.repository.*;

public class ProductServiceImpl implements ProductService{

	ProductRepossitory prodRepo = new ProductRepositoryImpl();

	@Override
	public boolean isAddNewProduct(Product model) {
		// TODO Auto-generated method stub
		return prodRepo.isAddNewProduct(model);
	}
	public List getAllProducts() {
		return prodRepo.getAllProducts();
	}

	
}
